/***************************************************************************
 * Name: David Keen
 * Date and Time: 
 * Function: 
 * Input requirements:                                  
 * Output: 
 * Additional Comments:
 *                                                                     	
 ***************************************************************************/
 
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include "Gameboard.h"


int main(int argc, char** argv) 
{
	Gameboard game; 
	game.sim();
}
